const CACHE_NAME = "primary-medication-v45";
const APP_SHELL = ["./", "./index.html", "./style.css", "./header-layout.css", "./text-mark-fix.css", "./drugs.js", "./catalog-retirements.js", "./outpatient-drugs.js", "./outpatient-web-verification.js", "./drug-lookup.js", "./pharmacy-scope.js", "./chinese-drug-labels.json?v=12", "./app.js", "./outpatient-metadata-ui.js", "./fast-search-ui.js", "./smart-add-fix.js", "./free-smart-source-v11.js", "./notebook-scroll-fix.js", "./mark-notebook-ui.js", "./mark-menu-below-selection.js", "./header-brand.js", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request).then(response => response || caches.match("./index.html")))
  );
});
